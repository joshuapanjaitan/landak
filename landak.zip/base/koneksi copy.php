<?php
	// $con= mysql_connect ("localhost","wwwsand1_dharma","sa912landakdharma");
	// mysql_select_db ("wwwsand1_landak",$con);
	$con = mysqli_connect("localhost", "root", "", "bz_landak");
?>