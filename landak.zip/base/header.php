					<h1>
						<a href="index.php"><img src="<?php echo $txt['txt_logo']; ?>" alt="Sandi Landak Teknologi" /><?php echo $txt['txt_logo_name']; ?></a>
					</h1>
					<nav>
						<ul class="menu responsive-menu">
						<?php
						$menuQ = mysqli_query($con, "SELECT * FROM ms_menu WHERE menu_status = 1 AND menu_parent = 0 ORDER BY menu_position ASC");
						while($menu = mysqli_fetch_array($menuQ)){
						$idMenu 	= $menu['menu_id'];						
						?>
							<li <?php if($page == $menu['menu_page']) echo 'class="current"'; ?>>
							<a href="<?php echo $menu['menu_url']; ?>"><?php echo $menu['menu_name']; ?></a>
								<?php 
								$submenuCekQ = mysqli_query($con, "SELECT menu_parent FROM ms_menu WHERE menu_status = 1 AND menu_parent > 0 ORDER BY menu_position ASC");
								$submenuCek = mysqli_fetch_array($submenuCekQ);
								$parentMenu = $submenuCek['menu_parent'];
								if($idMenu == $parentMenu){
								?>
								<ul>
									<?php 
									$submenuQ = mysqli_query($con, "SELECT * FROM ms_menu WHERE menu_status = 1 AND menu_parent > 0 ORDER BY menu_position ASC");
									while($submenu = mysqli_fetch_array($submenuQ)){
									?>
									<li><a href="<?php echo $submenu['menu_url']; ?>"><?php echo $submenu['menu_name']; ?></a></li>
									<?php } ?>
								</ul>
								<?php } ?>
							</li>
						<?php } ?>
						</ul>
					</nav>