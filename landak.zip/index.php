<?php
include("base/koneksi.php");
$txt = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_text WHERE txt_id = 1"));
$page = "home";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>.: Sandi Landak :.</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/skeleton.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/superfish.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/slider.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Maven+Pro:400,500,700' rel='stylesheet' type='text/css'>
	<script src="js/jquery-1.7.1.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/jquery.hoverIntent.js"></script>
	<script src="js/jquery.responsivemenu.js"></script>
	<script src="js/slides.min.jquery.js"></script>
	<script src="js/jquery.easing.1.3.js" type="text/javascript"></script>
	<script>
		$(function(){
			$('#slides').slides({
				effect: 'fade',
				fadeSpeed:700,
				play: 7000,
				pause: 4000,
				generatePagination: true,
				crossfade: true,
				hoverPause: true,
				animationStart: function(current){$('.caption').animate({left:-999},200);},
				animationComplete: function(current){$('.caption').animate({left:0},300);},
				slidesLoaded: function() {$('.caption').animate({left:0},300);}
			});
		});
	</script>
	<!--[if lt IE 8]>
		<div style='clear: both; text-align:center; position: relative;'>
			<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
				<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today.">
			</a>
		</div>
	<![endif]-->
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css"> 
	<![endif]-->
</head>
<body id="page1">
	<!--======================== header ============================-->
	<header>
		<?php include "base/header-panel.html"; ?>
		<div class="container_12">
			<div class="grid_12">
				<div class="border-bottom">
					<!--======================== logo & menu ============================-->
					<?php include "base/header.php"; ?>
					<div class="clear"></div>
				</div>
				<!--=================== slider ==================-->
				<div id="slides">
					<div class="slides_container">
						<?php
						$sliderQ = mysqli_query($con, "SELECT * FROM ms_slider ORDER BY sli_id ASC");
						while($slider = mysqli_fetch_array($sliderQ)){
						?>
						<div class="slide">
							<img src="<?php echo $slider['sli_image']; ?>">
							<div class="slider-border">
								<div class="caption">
									<p class="p5">
										<span class="row1 indents1"><?php echo $slider['sli_text1']; ?></span>
										<span class="row2 indents2"><?php echo $slider['sli_text2']; ?></span>
										<span class="row3 indents3"><?php echo $slider['sli_text3']; ?></span>
									</p>
								</div>
							</div>
						</div>
						<?php } ?>
					</div>
				</div>
			</div>
			<div class="clear"></div>
		</div>
	</header>
	
	<!--======================== aside ===========================-->
	<aside>
		<div class="container_12">
			<?php
			$rownya = Array();
			$cekRowQ = mysqli_query($con, "SELECT subsrv_homerow FROM ms_subservices WHERE subsrv_homerow > 0 GROUP BY subsrv_homerow");
			while($cekRow = mysqli_fetch_array($cekRowQ)){
				$rownya[] = $cekRow['subsrv_homerow'];
			}
			$rowCount = count($rownya);
			for($i = 1; $i <= $rowCount; $i++){
			?>
			<div class="wrapper">
				<?php $c1 = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_subservices WHERE subsrv_homerow = $i AND subsrv_home = 1"));
				if($c1){ ?>
				<div class="grid_4">
					<h4 class="p3-1"><?php echo $c1['subsrv_header']; ?></h4>
					<?php echo $c1['subsrv_shortcontent']; ?>
					<a href="services.php?id=<?php echo $c1['subsrv_id']; ?>" class="button">More</a>
				</div>
				<?php } ?>
				
				<?php $c2 = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_subservices WHERE subsrv_homerow = $i AND subsrv_home = 2"));
				if($c2){ ?>
				<div class="grid_4">
					<h4 class="p3-1"><?php echo $c2['subsrv_header']; ?></h4>
					<?php echo $c2['subsrv_shortcontent']; ?>
					<a href="services.php?id=<?php echo $c2['subsrv_id']; ?>" class="button">More</a>
				</div>
				<?php } ?>
				<?php $c3 = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_subservices WHERE subsrv_homerow = $i AND subsrv_home = 3"));
				if($c3){ ?>
				<div class="grid_4">
					<h4 class="p3-1"><?php echo $c3['subsrv_header']; ?></h4>
					<?php echo $c3['subsrv_shortcontent']; ?>
					<a href="services.php?id=<?php echo $c3['subsrv_id']; ?>" class="button">More</a>
				</div>
				<?php } ?>
			</div>
			<?php } ?>
		</div>
	</aside>
	<!--======================== footer ============================-->
	<?php include "base/footer.html"; ?>
</body>
</html>