/*
 Navicat Premium Data Transfer

 Source Server         : Localhost
 Source Server Type    : MySQL
 Source Server Version : 100411
 Source Host           : localhost:3306
 Source Schema         : bz_landak

 Target Server Type    : MySQL
 Target Server Version : 100411
 File Encoding         : 65001

 Date: 20/12/2021 16:53:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for ms_about
-- ----------------------------
DROP TABLE IF EXISTS `ms_about`;
CREATE TABLE `ms_about`  (
  `abt_id` int(11) NOT NULL AUTO_INCREMENT,
  `abt_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`abt_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_about
-- ----------------------------
INSERT INTO `ms_about` VALUES (1, 'Our Company');
INSERT INTO `ms_about` VALUES (2, 'What We Do');

-- ----------------------------
-- Table structure for ms_menu
-- ----------------------------
DROP TABLE IF EXISTS `ms_menu`;
CREATE TABLE `ms_menu`  (
  `menu_id` int(2) NOT NULL AUTO_INCREMENT,
  `menu_page` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `menu_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `menu_url` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `menu_status` int(1) NULL DEFAULT NULL,
  `menu_position` int(1) NULL DEFAULT NULL,
  `menu_parent` int(2) NULL DEFAULT NULL,
  PRIMARY KEY (`menu_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_menu
-- ----------------------------
INSERT INTO `ms_menu` VALUES (1, 'home', 'Home', 'index.php', 1, 1, 0);
INSERT INTO `ms_menu` VALUES (2, 'about', 'About', '#', 1, 2, 0);
INSERT INTO `ms_menu` VALUES (3, 'services', 'Products', 'services.php', 1, 3, 0);
INSERT INTO `ms_menu` VALUES (4, 'news', 'News', 'news.php', 1, 4, 0);
INSERT INTO `ms_menu` VALUES (5, 'contact', 'Contact Us', 'contact.php', 1, 5, 0);
INSERT INTO `ms_menu` VALUES (6, 'company', 'Our Company', 'about.php', 1, 1, 2);
INSERT INTO `ms_menu` VALUES (7, 'clients', 'Our Clients', 'about-clients.php', 1, 2, 2);
INSERT INTO `ms_menu` VALUES (8, 'partners', 'Our Partners', 'about-partners.php', 1, 3, 2);
INSERT INTO `ms_menu` VALUES (9, 'success', 'Success Stories', 'about-story.php', 1, 4, 2);

-- ----------------------------
-- Table structure for ms_operator
-- ----------------------------
DROP TABLE IF EXISTS `ms_operator`;
CREATE TABLE `ms_operator`  (
  `opr_id` int(11) NOT NULL AUTO_INCREMENT,
  `opr_username` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `opr_password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `opr_nama` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`opr_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_operator
-- ----------------------------
INSERT INTO `ms_operator` VALUES (1, 'bezhoe', '202cb962ac59075b964b07152d234b70', 'Firman Solihuddin');
INSERT INTO `ms_operator` VALUES (2, 'dharma', '202cb962ac59075b964b07152d234b70', 'Dharma Wijaya');

-- ----------------------------
-- Table structure for ms_services
-- ----------------------------
DROP TABLE IF EXISTS `ms_services`;
CREATE TABLE `ms_services`  (
  `srv_id` int(11) NOT NULL AUTO_INCREMENT,
  `srv_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`srv_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_services
-- ----------------------------
INSERT INTO `ms_services` VALUES (5, 'Authentication Server');
INSERT INTO `ms_services` VALUES (6, 'Hardware token');

-- ----------------------------
-- Table structure for ms_slider
-- ----------------------------
DROP TABLE IF EXISTS `ms_slider`;
CREATE TABLE `ms_slider`  (
  `sli_id` int(1) NOT NULL AUTO_INCREMENT,
  `sli_text1` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sli_text2` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sli_text3` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `sli_image` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`sli_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_slider
-- ----------------------------
INSERT INTO `ms_slider` VALUES (2, '', '', '', 'gambar/slider/sli_2.png');
INSERT INTO `ms_slider` VALUES (3, '', '', '', 'gambar/slider/sli_3.png');
INSERT INTO `ms_slider` VALUES (4, '', '', '', 'gambar/slider/sli_4.png');

-- ----------------------------
-- Table structure for ms_subabout
-- ----------------------------
DROP TABLE IF EXISTS `ms_subabout`;
CREATE TABLE `ms_subabout`  (
  `subabt_id` int(11) NOT NULL AUTO_INCREMENT,
  `abt_id` int(11) NULL DEFAULT NULL,
  `subabt_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `subabt_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `subabt_header` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `subabt_content` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`subabt_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_subabout
-- ----------------------------
INSERT INTO `ms_subabout` VALUES (1, 1, 'Who We Are', 'gambar/sabt_1.jpg', 'We bring trust to an increasingly connected digital world', '<h3>World leader in digital security</h3>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>We deliver easy to use technologies and services to businesses and governments, authenticating identities and protecting data so they stay safe and enable services in personal devices, connected objects, the cloud and in between.&nbsp;</p>\r\n');
INSERT INTO `ms_subabout` VALUES (2, 2, 'Our Expertise', 'gambar/sabt_2.jpg', 'Our unique experience in digital security generates value for businesses and governments', '<p>Our&nbsp;unique experience in digital security generates value for businesses and governments by protecting identities and data wherever they are. We do this in two interconnecting ways.</p>\r\n\r\n<p>Our solutions are at the heart of modern life, from payment to enterprise security and the internet of things. We authenticate people, transactions and objects, encrypt data and create value for software - enabling our clients&nbsp;to deliver secure digital services.</p>\r\n');

-- ----------------------------
-- Table structure for ms_subservices
-- ----------------------------
DROP TABLE IF EXISTS `ms_subservices`;
CREATE TABLE `ms_subservices`  (
  `subsrv_id` int(11) NOT NULL AUTO_INCREMENT,
  `srv_id` int(11) NULL DEFAULT NULL,
  `subsrv_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `subsrv_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `subsrv_header` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `subsrv_content` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `subsrv_shortcontent` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `subsrv_homerow` int(2) NOT NULL,
  `subsrv_home` int(1) NOT NULL,
  PRIMARY KEY (`subsrv_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_subservices
-- ----------------------------
INSERT INTO `ms_subservices` VALUES (6, 5, 'Salt Echidna', 'gambar/ssrv_6.png', 'Salt Echidna MFA Authentication Services', '<h2 style=\"text-align:justify\">Echidna is an enterprise grade authentication server, which has been developed to support high availability, high volume and high assurance user authentication applications in banks, government departments and enterprises, globally.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna has been designed to integrate with and extend existing firewalls and perimeter solutions to provide a simple to manage and deploy two-factor user authentication (2FA) solution.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna is suitable for any organisation that has a need to provide an additional level of user authentication through utilising a two-factor mechanism, be that a mobile or hardware security token.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna supports a seamless migration from exiting 2FA solutions, which allows an organisation to easily migrate from ageing and expensive token solutions whilst protecting their investment during the transition stage.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna provides a solution that allows an organisation to adopt new authentication mechanisms as they emerge, without expensive retrofit or system remediation.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna provides a flexible unified 2FA user authentication service available via RADIUS and web service protocols. It also makes available transaction and document signing mechanisms via web services for applications needing to directly integrate at a more granular level.</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna interfaces to a range of Identity and Access Management (IDAM) infrastructures and to general-purpose access gateways through either web services or RADIUS to provide user authentication services</h2>\r\n\r\n<h2 style=\"text-align:justify\">Echidna supports a comprehensive range of authentication standards and mechanisms and device form factors from a range of vendors, including OATH.</h2>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n', '<p><em><strong>Echidna is an enterprise grade authentication server, which has been developed to support high availability, high volume and high assurance user authentication applications in banks, government departments and enterprises, globally.</strong></em></p>\r\n', 1, 2);
INSERT INTO `ms_subservices` VALUES (8, 6, 'Ezio Pico', 'gambar/ssrv_8.png', 'EZIO PICO', '<h2>A signing token enabling secure online banking transactions and authenticatâ€‹ion, is highly scalable and can be adapted to fit any bank&#39;s business needs.</h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>Compact signing token</li>\r\n	<li>Ultra thin and compact with size of 70.1 mm * 44 mm * 3.4 mm</li>\r\n	<li>Weighs less than 15 g</li>\r\n	<li>In compliance â€‹with OATH-OCRA</li>\r\n	<li>Customizable with branding possibilities</li>\r\n</ul>\r\n', '<p>A signing token enabling secure online banking transactions and authenticatâ€‹ion, is highly scalable and can be adapted to fit any bank&#39;s business needs.</p>\r\n', 0, 0);
INSERT INTO `ms_subservices` VALUES (9, 6, 'Ezio Lava', 'gambar/ssrv_9.png', 'EZIO LAVA', '<h2>One-button token with great branding possibilities and available in two versions, time- or event-based OTP generation.</h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ul>\r\n	<li>\r\n	<p>One-button token with great branding possibilities for time-based OTP generation</p>\r\n	</li>\r\n	<li>\r\n	<p>Light and compact and weighs less than 11g</p>\r\n	</li>\r\n	<li>\r\n	<p>Time-or event-based OTP generation</p>\r\n	</li>\r\n	<li>\r\n	<p>Customizable with branding possibilities</p>\r\n	</li>\r\n</ul>\r\n', '<p>One-button token with great branding possibilities and available in two versions, time- or event-based OTP generation.</p>\r\n', 0, 0);

-- ----------------------------
-- Table structure for ms_text
-- ----------------------------
DROP TABLE IF EXISTS `ms_text`;
CREATE TABLE `ms_text`  (
  `txt_id` int(2) NOT NULL AUTO_INCREMENT,
  `txt_contact_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `txt_contact_content` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `txt_logo` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `txt_logo_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `txt_support` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `txt_email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `txt_map` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  PRIMARY KEY (`txt_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ms_text
-- ----------------------------
INSERT INTO `ms_text` VALUES (1, 'PT Sandi Landak Teknologi', '<p>The Vida 7th floor, Jln. Raya Perjuangan No.8, Jakarta Barat 11530, Indonesia<br />\r\nPhone : +6221 2977 8150<br />\r\nE-mail :&nbsp;<a href=\"mailto:dharma.wijaya@sandilandak.com\">dharma.wijaya@sandilandak.com</a></p>\r\n', 'images/logo_name.png', 'Sandi Landak Teknologi', 'The Vida 7th floor, Jakarta Barat, Indonesia', 'info@sandilandak.com', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1983.273749313327!2d106.7594024!3d-6.1912486!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f71955eae421%3A0xc0df35898597044a!2sTHE+VIDA+OFFICE+BUILDING!5e0!3m2!1sen!2sid!4v1485760110141\" width=\"800\" height=\"600\" frameborder=\"0\" style=\"border:0\" allowfullscreen></iframe>');

-- ----------------------------
-- Table structure for tr_clients
-- ----------------------------
DROP TABLE IF EXISTS `tr_clients`;
CREATE TABLE `tr_clients`  (
  `part_id` int(11) NOT NULL AUTO_INCREMENT,
  `part_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `part_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`part_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tr_clients
-- ----------------------------
INSERT INTO `tr_clients` VALUES (1, 'gambar/clients_1.jpg', 'Inactive');
INSERT INTO `tr_clients` VALUES (2, 'gambar/clients_2.jpg', 'Inactive');
INSERT INTO `tr_clients` VALUES (3, 'gambar/clients_3.jpg', 'Inactive');

-- ----------------------------
-- Table structure for tr_news
-- ----------------------------
DROP TABLE IF EXISTS `tr_news`;
CREATE TABLE `tr_news`  (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `n_header` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `n_date` date NULL DEFAULT NULL,
  `n_short` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `n_long` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `n_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`n_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for tr_partners
-- ----------------------------
DROP TABLE IF EXISTS `tr_partners`;
CREATE TABLE `tr_partners`  (
  `part_id` int(11) NOT NULL AUTO_INCREMENT,
  `part_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `part_content` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `part_link` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `part_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `part_status` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`part_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tr_partners
-- ----------------------------
INSERT INTO `tr_partners` VALUES (1, 'Salt Group', '<p>.</p>\r\n', 'http://saltechidna.com/', 'gambar/partners_1.jpg', 'Active');
INSERT INTO `tr_partners` VALUES (2, 'Gemalto', '<p>.</p>\r\n', 'http://www.gemalto.com/', 'gambar/partners_2.jpg', 'Active');
INSERT INTO `tr_partners` VALUES (3, 'bedil', '<p>asjhe awhe awke awe awea weawe aweawe awea weaw eawkea jwhekuawgvekawv ekawbe kawe aweawd</p>\r\n', 'http://www.bezhoe.com/', 'gambar/partners_3.jpg', 'Inactive');
INSERT INTO `tr_partners` VALUES (4, 'llllllllllllll', '<p>klklklklklkklklklklklklcfv</p>\r\n', 'klklklklkkl', 'gambar/partners_4.jpg', 'Inactive');

-- ----------------------------
-- Table structure for tr_serv_document
-- ----------------------------
DROP TABLE IF EXISTS `tr_serv_document`;
CREATE TABLE `tr_serv_document`  (
  `doc_id` int(11) NOT NULL AUTO_INCREMENT,
  `subsrv_id` int(11) NULL DEFAULT NULL,
  `doc_name` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `doc_file` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`doc_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tr_serv_document
-- ----------------------------
INSERT INTO `tr_serv_document` VALUES (1, 1, 'Concept Guide', 'upload/ssrv_1_1.pdf');
INSERT INTO `tr_serv_document` VALUES (2, 1, 'Administration Guide', 'upload/ssrv_1_2.pdf');
INSERT INTO `tr_serv_document` VALUES (3, 2, 'Salt Group', 'upload/ssrv_2_3.pdf');
INSERT INTO `tr_serv_document` VALUES (4, 6, 'Salt Echidna - Brochure', 'upload/ssrv_6_4.pdf');
INSERT INTO `tr_serv_document` VALUES (5, 6, 'Salt Echidna Concepts Guide - Technical Doc', 'upload/ssrv_6_5.pdf');
INSERT INTO `tr_serv_document` VALUES (6, 8, 'Ezio Pico - Brochure', 'upload/ssrv_8_6.pdf');
INSERT INTO `tr_serv_document` VALUES (7, 9, 'Ezio Lava - Brochure', 'upload/ssrv_9_7.pdf');

-- ----------------------------
-- Table structure for tr_story
-- ----------------------------
DROP TABLE IF EXISTS `tr_story`;
CREATE TABLE `tr_story`  (
  `n_id` int(11) NOT NULL AUTO_INCREMENT,
  `n_header` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `n_date` date NULL DEFAULT NULL,
  `n_short` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `n_long` text CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL,
  `n_picture` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`n_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;
