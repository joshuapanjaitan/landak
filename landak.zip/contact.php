<?php
include("base/koneksi.php");
$page = "contact";
$txt = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_text WHERE txt_id = 1"));
$pagemenu = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_menu WHERE menu_page = '$page'"));
date_default_timezone_set("Asia/Jakarta");

$info = "";

require_once('contact-function.php');
if(isset($_POST['submit']))
{
	$cname 		= @$_POST['name'];
	$cemail		= @$_POST['email'];
	$cphone		= @$_POST['phone'];
	$cmessage	= @$_POST['message'];
	
	if($cname == "" || $cemail == "" || $cphone == "" || $cmessage == "")
		$info = "*Please fill all fields.<br><br>";
	else
	{
		$toEmail	= $txt['txt_email'];
		$to       	= $toEmail;
		$subject  	= 'Contact Form - Sandi Landak';
		$message  	= '<p>Name : '.$cname.'</p>
		<p>Email : '.$cemail.'</p>
		<p>Phone : '.$cphone.'</p>
		<p>Message : '.$cmessage.'</p>';
		smtp_mail($to, $subject, $message, '', '', 0, 0, false);
		$info = "*Contact form submitted!<br><strong>We will be in touch soon.</strong><br><br>";
	}
}
else
	$info = "";
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>.: Sandi Landak - <?php echo $pagemenu['menu_name']; ?> :.</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/skeleton.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/superfish.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/forms.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Maven+Pro:400,500,700' rel='stylesheet' type='text/css'>
	<script src="js/jquery-1.7.1.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/jquery.hoverIntent.js"></script>
	<script src="js/jquery.responsivemenu.js"></script>
	<!--[if lt IE 8]>
		<div style='clear: both; text-align:center; position: relative;'>
			<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
				<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today.">
			</a>
		</div>
	<![endif]-->
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css"> 
	<![endif]-->
	<!--[if IE 9]>
		<style>
			#contact-form input {padding:10px 9px 9px;}
		</style>
	<![endif]-->
</head>
<body id="page6">
	<!--======================== header ============================-->
	<header>
		<?php include "base/header-panel.html"; ?>
		<div class="container_12">
			<div class="grid_12 border-bottom">
				<!--======================== logo & menu ============================-->
				<?php include "base/header.php"; ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
	</header>
	<!--======================== content ===========================-->
	<section id="content">
		<div class="container_12">
			<div class="wrapper">
				<div class="grid_4">
					<div class="indent-right7-1">
						<h3 class="p5-1">Contact <span>Info</span></h3>
						<!--=============== Map ====================-->
						<strong><?php echo $txt['txt_contact_name']; ?></strong><br><br>
						<?php echo $txt['txt_contact_content']; ?>
					</div>
				</div>
				
				<div class="grid_8">
					<div id="map">
						<figure class="p5">
							<?php echo $txt['txt_map']; ?>
						</figure>
					</div>
				</div>
				
				<!--
				<div class="grid_8">
					<div class="suffix_2">
						<h3 class="p5-1">Get <span>In Touch</span></h3>
						<form id="contact-form" action="contact.php" method="post">
							<?php echo $info; ?>
							<fieldset>
								<label class="name">Name :
									<input type="text" name="name">
								</label>
								<label class="email">E-Mail :
									<input type="text" name="email">
								</label>
								<label class="phone">Phone : 
									<input type="tel" name="phone">
								</label>
								<label class="message">Message :
									<textarea name="message"></textarea>
								</label>
								<div class="buttons-wrapper">
									<button type="submit" class="button" name="submit">Submit</button>
								</div>
							</fieldset>
						</form>
					</div>
				</div>
				-->
				
			</div>
		</div>
	</section>
	<!--======================== footer ============================-->
	<?php include "base/footer.html"; ?>
</body>
</html>