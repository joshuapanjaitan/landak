<?php
include("base/koneksi.php");
$page = "about";
$pagetree = "success";
$txt = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_text WHERE txt_id = 1"));
$pagemenu = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_menu WHERE menu_page = '$pagetree'"));
date_default_timezone_set("Asia/Jakarta");

$nid = "";
$nid = @$_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>.: Sandi Landak - <?php echo $pagemenu['menu_name']; ?> :.</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/skeleton.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/superfish.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Maven+Pro:400,500,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/accordion.css" type="text/css" media="screen">
	<script src="js/jquery-1.7.1.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/jquery.hoverIntent.js"></script>
	<script src="js/jquery.responsivemenu.js"></script>
	<!--[if lt IE 8]>
		<div style='clear: both; text-align:center; position: relative;'>
			<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
				<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdateed browser. For a faster, safer browsing experience, upgrade for free today.">
			</a>
		</div>
	<![endif]-->
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css"> 
	<![endif]-->
</head>
<body id="page3">
	<!--======================== header ============================-->
	<header>
		<?php include "base/header-panel.html"; ?>
		<div class="container_12">
			<div class="grid_12 border-bottom">
				<!--======================== logo & menu ============================-->
				<?php include "base/header.php"; ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
	</header>
	<!--======================== content ===========================-->
	<section id="content">
		<div class="container_12">
			<?php if($nid == ""){ ?>
			<div class="wrapper">
				<h3 class="p5"><span><?php echo $pagemenu['menu_name']; ?></span></h3>
				
				<?php
				$result = mysqli_query($con, "SELECT COUNT(*) FROM tr_story");
				$r = mysqli_fetch_row($result);
				$numrows = $r[0];

				$rowsperpage = 6;
				$totalpages = ceil($numrows / $rowsperpage);

				if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage']))
					$currentpage = (int) $_GET['currentpage'];
				else
					$currentpage = 1;

				if ($currentpage > $totalpages)
				   $currentpage = $totalpages;
			   
				if ($currentpage < 1) 
					$currentpage = 1;

				$offset = ($currentpage - 1) * $rowsperpage;
				$result = mysqli_query($con, "SELECT n_id, n_header, n_date, n_short FROM tr_story ORDER BY n_date DESC LIMIT $offset, $rowsperpage");
				while ($list = mysql_fetch_assoc($result)) {
					$datee = new dateTime($list['n_date']);
					$datee = $datee->format('F j, Y');
				?>
				<div class="grid_6">
					<div class="p2"><br>
						<div class="block1"><div class="text"><?php echo $datee; ?></div></div>
						<h4 class="p3-1"><?php echo $list['n_header']; ?></h4>
						<?php echo $list['n_short']; ?>
					</div>
					<a href="about-story.php?id=<?php echo $list['n_id']; ?>" class="button" style="padding:4px 11px 4px; font:500 15px/15px 'Maven Pro', sans-serif;">Read More</a>
				</div>
				<?php } ?>
				
				<div class="clearfix"></div><br><br>
				
				<div class="grid_12">
					<div style="font-size:14px; text-align:center">
						<?php
						$range = 3;						
						if ($currentpage > 1) 
						{
						   echo " <a href='about-story.php?currentpage=1'><<</a> ";
						   $prevpage = $currentpage - 1;
						   echo " <a href='about-story.php?currentpage=$prevpage'><</a> ";
						}

						for ($x = ($currentpage - $range); $x < (($currentpage + $range) + 1); $x++) {
							if (($x > 0) && ($x <= $totalpages)) 
							{
								if ($x == $currentpage)
									echo " [<b>$x</b>] ";
								else 
									echo " <a href='about-story.php?currentpage=$x'>$x</a> ";
							}
						}
						if ($currentpage != $totalpages) 
						{
							$nextpage = $currentpage + 1;
							echo " <a href='about-story.php?currentpage=$nextpage'>></a> ";
							echo " <a href='about-story.php?currentpage=$totalpages'>>></a> ";
						}
						?>
					</div>
				</div>
				
			</div>
			<?php }else{ 
			$dnewsQ = mysqli_query($con, "SELECT * FROM tr_story WHERE n_id = $nid");
			$dnews = mysqli_fetch_array($dnewsQ);
			$datee = new dateTime($dnews['n_date']);
			$datee =  $datee->format('F j, Y');
			?>
			<div class="wrapper">
				<div class="grid_9">
					<div class="indent-right5 indent-bottom7-1">
						<?php echo $datee; ?>
						<h3 class="p5"><span><?php echo $dnews['n_header']; ?></span></h3>
						<div class="wrapper">
							<figure class="img-indent img-indent-none-ml">
								<img src="<?php echo $dnews['n_picture']; ?>" width="100%">
							</figure>
							<?php echo $dnews['n_long']; ?>
						</div>
					</div>
				</div>
				<div class="grid_3">
					<h4 class="p4">Latest News</h4>
					<ul class="list-1">
						<?php 
						$listQ = mysqli_query($con, "SELECT n_id, n_header FROM tr_story ORDER BY n_id DESC LIMIT 10");
						while($list = mysqli_fetch_array($listQ)){ ?>
						<li><a href="about-story.php?id=<?php echo $list['n_id']; ?>"><?php echo $list['n_header']; ?></a></li>
						<?php } ?>
					</ul>
				</div>
			</div>
			<?php } ?>
		</div>
	</section>
	<!--======================== footer ============================-->
	<?php include "base/footer.html"; ?>
</body>
</html>