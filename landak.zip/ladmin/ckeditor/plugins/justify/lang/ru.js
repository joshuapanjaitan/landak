/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'ru', {
	block: 'По ширине',
	center: 'По центру',
	left: 'По левому краю',
	right: 'По правому краю'
} );
