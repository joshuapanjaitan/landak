CKEDITOR.plugins.setLang('wordcount', 'pt', {
    WordCount: 'Palavras:',
    CharCount: 'Caracteres:',
    CharCountWithHTML: 'Carateres (incluindo HTML):',
    Paragraphs: 'Parágrafos:',
    pasteWarning: 'O conteúdo não pode ser colado porque ultrapassa o limite permitido',
    Selected: 'Selecionado: ',
    title: 'Estatísticas'
});
