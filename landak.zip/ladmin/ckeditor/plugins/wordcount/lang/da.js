/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang('wordcount', 'da', {
    WordCount: 'Ord:',
    CharCount: 'Karakterer:',
    CharCountWithHTML: 'Karakterer (med HTML):',
    Paragraphs: 'Afsnit:',
    pasteWarning: 'Indholdet kan ikke indsættes da det er længere end den tilladte grænse.',
    Selected: 'Markeret: ',
    title: 'Statistik'
});
