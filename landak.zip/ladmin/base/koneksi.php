<?php
	date_default_timezone_set("Asia/Jakarta");
	$con = mysqli_connect("localhost", "wwwsand1_dharma", "sa912landakdharma", "wwwsand1_landak");
	$ai	= "salandak_db";
	
 /*
	; Maximum allowed size for uploaded files.
	upload_max_filesize = 40M

	; Must be greater than or equal to upload_max_filesize
	post_max_size = 40M
	*/
?>