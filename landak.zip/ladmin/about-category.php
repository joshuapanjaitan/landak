<?php
session_start();
include("base/koneksi.php");
$page		= "about";
$pagetree	= "aboutcategory";

$idadmin = $_SESSION['idadmin'];
if($idadmin == ""){
	$_SESSION['error'] = "Silahkan login terlebih dahulu";
	header("location:index.php");
}

$namaOpr = $_SESSION['nama'];

$info = "";
$info = @$_GET['info'];

$idabt = "";
$idabt = @$_GET['idabt'];

$idsabt = "";
$idsabt = @$_GET['idsabt'];

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Sandi Landak Teknologi Administrator</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="icon" href="base/favicon.png" type="image/x-icon">

	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="dist/css/font-awesome-4.6.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="dist/css/ionicons-2.0.1/css/ionicons.min.css">
	<link rel="stylesheet" href="dist/css/AdminLTE.min.css">
	<link rel="stylesheet" href="dist/css/skins/skin-blue.min.css">
	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/config.js"></script>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  
  <?php include "base/header.html"; ?>
  <?php include "base/sidebar.html"; ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>Our Company - Kategori<small><?php echo $info; ?></small></h1>
    </section>

    <section class="content">
      <div class="row">
		
		<!-- add about -->
		<?php if($idabt == "" && $idsabt == ""){ ?>
		<form action="scripts/about.php" method="post">
        <input type="hidden" value="kategori" name="about" />
		<input type="hidden" value="x" name="idabt" />
		<div class="col-md-5">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah Kategori</h3>
            </div>
              <div class="box-body">
			  
                <div class="form-group col-md-12">
                  <label for="abt_name" class="col-sm-12 control-label">Nama Kategori</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="abt_name">
                  </div>
                </div>

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary pull-right">Submit</button>
                <a href="about-category.php" class="btn btn-default">Reset</a>
			  </div>
          </div>
        </div>
        </form>
		
		<form action="scripts/about.php" method="post">
        <input type="hidden" value="subkategori" name="about" />
		<input type="hidden" value="x" name="idsabt" />
		<div class="col-md-7">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Tambah Sub Kategori</h3>
            </div>
              <div class="box-body">
			  
				<div class="form-group col-md-6">
					<label for="abt_id" class="col-sm-12 control-label">Kategori</label>
					<div class="col-sm-12">
						<select class="form-control" name="abt_id">
							<option value="">Pilih kategori..</option>
							<?php
							$pickAbtQ = mysqli_query($con, "select abt_id, abt_name FROM ms_about ORDER BY abt_id ASC");
							while($pickAbt = mysqli_fetch_array($pickAbtQ)){
							?>
							<option value="<?php echo $pickAbt['abt_id']; ?>"><?php echo $pickAbt['abt_name']; ?></option>
							<?php } ?>
						</select>
					</div>
                </div>
				
                <div class="form-group col-md-6">
                  <label for="subabt_name" class="col-sm-12 control-label">Nama Sub Kategori</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="subabt_name">
                  </div>
                </div>

              </div>
              <div class="box-footer">
                <button type="submit" class="btn btn-primary pull-right">Submit</button>
                <a href="about-category.php" class="btn btn-default">Reset</a>
			  </div>
          </div>
        </div>
        </form>
		<?php } ?>
		<!-- /add about -->
		
        <!-- Modifikasi about -->
		<?php
		if($idabt != ""){
		$editAbtQ = mysqli_query($con, "select * FROM ms_about WHERE abt_id = '$idabt'");
		$editAbt = mysqli_fetch_array($editAbtQ);
		?>
		<form action="scripts/about.php" method="post">
        <input type="hidden" value="kategori" name="about" />
		<input type="hidden" value="<?php echo $idabt; ?>" name="idabt" />
		<div class="col-md-5">
          <div class="box box-info">
		  
            <div class="box-header with-border">
              <h3 class="box-title">Edit Kategori</h3>
            </div>
			
				<div class="box-body">
			  
					<div class="form-group col-md-12">
					  <label for="abt_name" class="col-sm-12 control-label">Nama Kategori</label>
					  <div class="col-sm-12">
						<input type="text" class="form-control" name="abt_name" value="<?php echo $editAbt['abt_name']; ?>">
					  </div>
					</div>

				</div>
				
				<div class="box-footer" style="background:#eee">
					<button type="submit" class="btn btn-primary pull-right">Submit</button>
					<a href="about-category.php" class="btn btn-default">Reset</a>
				</div>
          </div>
        </div>
        </form>
		<?php } ?>
		
		<?php
		if($idsabt != ""){
		$editSAbtQ = mysqli_query($con, "select * FROM ms_subabout WHERE subabt_id = '$idsabt'");
		$editSAbt = mysqli_fetch_array($editSAbtQ);
		?>
		<form action="scripts/about.php" method="post">
        <input type="hidden" value="subkategori" name="about" />
		<input type="hidden" value="<?php echo $idsabt; ?>" name="idsabt" />
		<div class="col-md-7">
          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Sub Kategori</h3>
            </div>
              <div class="box-body">
			  
				<div class="form-group col-md-6">
					<label for="abt_id" class="col-sm-12 control-label">Kategori</label>
					<div class="col-sm-12">
						<select class="form-control" name="abt_id">
							<option value="">Pilih kategori..</option>
							<?php
							$pickAbtQ = mysqli_query($con, "select abt_id, abt_name FROM ms_about ORDER BY abt_id ASC");
							while($pickAbt = mysqli_fetch_array($pickAbtQ)){
							?>
							<option value="<?php echo $pickAbt['abt_id']; ?>" <?php if($pickAbt['abt_id'] == $editSAbt['abt_id']) echo "selected"; ?>><?php echo $pickAbt['abt_name']; ?></option>
							<?php } ?>
						</select>
					</div>
                </div>
				
				<div class="form-group col-md-6">
                  <label for="subabt_name" class="col-sm-12 control-label">Nama Sub Kategori</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="subabt_name" value="<?php echo $editSAbt['subabt_name']; ?>">
                  </div>
                </div>
				
			  </div>
			  
			  <div class="box-footer" style="background:#eee">
                <button type="submit" class="btn btn-primary pull-right">Submit</button>
                <a href="serv-category.php" class="btn btn-default">Reset</a>
			  </div>
          </div>
        </div>
        </form>
		<?php } ?>
		<!-- /Modifikasi about -->
		
		<div class="clearfix"></div>
		
		<!-- about -->
		<div class="col-md-5">
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">Daftar Kategori</h3>
            </div>
            <div class="box-body">
              <table id="example1" class="table table-hover">
                <thead>
                <tr>
                  <th>Action</th>
				  <th>Kategori</th>
                </tr>
                </thead>
                <tbody>
                <?php
				$servQ = mysqli_query($con, "SELECT abt_name, abt_id FROM ms_about ORDER BY abt_id ASC");
				while($serv = mysqli_fetch_array($servQ)){
				?>
				<tr>
				  <td><a href="about-category.php?idabt=<?php echo $serv['abt_id']; ?>">Edit</a> | <a href="scripts/about.php?about=delabt&idabt=<?php echo $serv['abt_id']; ?>">Delete</a></td>
                  <td><?php echo $serv['abt_name']; ?></td>
                </tr>
                <?php } ?>
				</tbody>
              </table>
            </div>
          </div>
        </div>
		<!-- /about -->
		
		<!-- Sub about -->
		<div class="col-md-7">
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">Daftar Sub Kategori</h3>
            </div>
            <div class="box-body">
              <table id="example2" class="table table-hover">
                <thead>
                <tr>
                  <th>Action</th>
				  <th>Kategori</th>
				  <th>Sub Kategori</th>
                </tr>
                </thead>
                <tbody>
                <?php
				$sabtQ = mysqli_query($con, "SELECT ss.subabt_id, s.abt_name, ss.subabt_name FROM ms_about s, 
				ms_subabout ss WHERE s.abt_id = ss.abt_id ORDER BY s.abt_id ASC");
				while($sabt = mysqli_fetch_array($sabtQ)){
				?>
				<tr>
				  <td><a href="about-category.php?idsabt=<?php echo $sabt['subabt_id']; ?>">Edit</a> | <a href="scripts/about.php?about=delsabt&idsabt=<?php echo $sabt['subabt_id']; ?>">Delete</a></td>
                  <td><?php echo $sabt['abt_name']; ?></td>
                  <td><?php echo $sabt['subabt_name']; ?></td>
                </tr>
                <?php } ?>
				</tbody>
              </table>
            </div>
          </div>
        </div>
		<!-- /Sub about -->
		
      </div>
    </section>
  </div>
  <?php include "base/footer.html"; ?>
</div>

<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>

<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="plugins/fastclick/fastclick.js"></script>
<script src="dist/js/app.min.js"></script>
<script src="dist/js/demo.js"></script>
<script>
$(function () {
	$('#example1').DataTable();
	$('#example2').DataTable();
});
</script>
</body>
</html>