<?php
session_start();
include("base/koneksi.php");
$page		= "about";
$pagetree	= "aboutsubcontent";

$idadmin = $_SESSION['idadmin'];
if($idadmin == ""){
	$_SESSION['error'] = "Silahkan login terlebih dahulu";
	header("location:index.php");
}

$id = "";
$id = @$_GET['id'];
$namaOpr = $_SESSION['nama'];
$info = "";
$info = @$_GET['info'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Sandi Landak Teknologi Administrator</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<link rel="icon" href="base/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="dist/css/font-awesome-4.6.3/css/font-awesome.min.css">
	<link rel="stylesheet" href="dist/css/ionicons-2.0.1/css/ionicons.min.css">
	<link rel="stylesheet" href="dist/css/AdminLTE.min.css">

	<link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
	<link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
	<script src="ckeditor/ckeditor.js"></script>
	<script src="ckeditor/config.js"></script>

	<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  
  <?php include "base/header.html"; ?>
  <?php include "base/sidebar.html"; ?>

  <div class="content-wrapper">
    <section class="content-header">
      <h1>Our Company - Sub Kategori<small><?php echo $info; ?></small></h1>
    </section>

    <section class="content">
      <div class="row">
	  
		<!-- Daftar Sub Kategori -->
		<div class="col-md-12">
		  <div class="box">
            <div class="box-header">
              <h3 class="box-title">Daftar Sub Kategori</h3>
            </div>
            <div class="box-body">
              <table id="example1" class="table table-hover">
                <thead>
                <tr>
                  <th>Action</th>
				  <th>Kategori</th>
				  <th>Sub Kategori</th>
				  <th>Header</th>
                </tr>
                </thead>
                <tbody>
                <?php
				$aboutQ = mysqli_query($con, "select * FROM ms_about s, ms_subabout ss WHERE s.abt_id = ss.abt_id ORDER BY ss.abt_id ASC");
				while($about = mysqli_fetch_array($aboutQ)){
				?>
				<tr>
				  <td><a href="about-subcontent.php?id=<?php echo $about['subabt_id']; ?>">Edit</a></td>
                  <td><?php echo $about['abt_name']; ?></td>
                  <td><?php echo $about['subabt_name']; ?></td>
                  <td><?php echo $about['subabt_header']; ?></td>
                </tr>
                <?php } ?>
				</tbody>
              </table>
            </div>
          </div>
        </div>
		<!-- /Daftar Sub Kategori -->
		
        <!-- Modifikasi Sub Kategori -->
		<?php
		if($id != ""){
		$editAbtCntQ = mysqli_query($con, "select * FROM ms_about s, ms_subabout ss WHERE s.abt_id = ss.abt_id AND ss.subabt_id = $id");
		$editAbtCnt = mysqli_fetch_array($editAbtCntQ);
		?>
		<form enctype="multipart/form-data" action="scripts/about-subcontent.php" method="post">
		<input type="hidden" value="<?php echo $id; ?>" name="idsabt" />
		<div class="col-md-12">

          <div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Edit Sub Kategori</h3>
            </div>
			
              <div class="box-body">
			  
				<div class="form-group col-md-6">
                  <label for="abt_name" class="col-sm-12 control-label">Nama Kategori</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="abt_name" value="<?php echo $editAbtCnt['abt_name']; ?>" readonly>
                  </div>
                </div>
				
				<div class="form-group col-md-6">
                  <label for="subabt_name" class="col-sm-12 control-label">Nama Sub Kategori</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="subabt_name" value="<?php echo $editAbtCnt['subabt_name']; ?>" readonly>
                  </div>
                </div>
				
				<div class="form-group col-md-12">
                  <label for="subabt_header" class="col-sm-12 control-label">Header</label>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="subabt_header" value="<?php echo $editAbtCnt['subabt_header']; ?>">
                  </div>
                </div>
				
				<div class="form-group col-md-12">
                  <label for="picture" class="col-sm-12 control-label">Picture</label>
                  <div class="col-sm-12">
                    <input type="file" name="file" id="file" /> 
                  </div>
                </div>
				
				<div class="form-group col-md-12">
                  <label for="subabt_content" class="col-sm-12 control-label">Content</label>
                  <div class="col-sm-12">
                    <textarea name="subabt_content" id="editor1" rows="10" cols="80"><?php echo $editAbtCnt['subabt_content']; ?></textarea>
                  </div>
                </div>

              </div>
			  
              <div class="box-footer" style="background:#eee">
                <button type="submit" class="btn btn-primary pull-right">Submit</button>
                <a href="about-subcontent.php" class="btn btn-default">Reset</a>
			  </div>
			  
          </div>
        </div>
        </form>
		<?php } ?>
		<!-- /Modifikasi Sub Kategori -->
		
      </div>
    </section>
  </div>
  <?php include "base/footer.html"; ?>
</div>

<script src="plugins/jQuery/jQuery-2.1.4.min.js"></script>
<script src="bootstrap/js/bootstrap.min.js"></script>
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="plugins/fastclick/fastclick.js"></script>
<script src="dist/js/app.min.js"></script>
<script src="dist/js/demo.js"></script>
<script>
$(function () {
	$('#example1').DataTable();
	<?php if($id != "") { ?>
	CKEDITOR.replace( 'editor1' );
	<?php } ?>
});
</script>
</body>
</html>
