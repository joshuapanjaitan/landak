<?php
include("base/koneksi.php");
$page = "about";
$pagetree = "company";
$txt = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_text WHERE txt_id = 1"));
$pagemenu = mysqli_fetch_array(mysqli_query($con, "SELECT * FROM ms_menu WHERE menu_page = '$pagetree'"));
$id = "";
$id = @$_GET['id'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>.: Sandi Landak - <?php echo $pagemenu['menu_name']; ?> :.</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width; initial-scale=1.0">
	<link rel="icon" href="images/favicon.png" type="image/x-icon">
	<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/skeleton.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/superfish.css" type="text/css" media="screen">
	<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
	<link href='http://fonts.googleapis.com/css?family=Maven+Pro:400,500,700' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/accordion.css" type="text/css" media="screen">
	<script src="js/jquery-1.7.1.min.js"></script>
	<script src="js/script.js"></script>
	<script src="js/superfish.js"></script>
	<script src="js/jquery.hoverIntent.js"></script>
	<script src="js/jquery.responsivemenu.js"></script>
	<!--[if lt IE 8]>
		<div style='clear: both; text-align:center; position: relative;'>
			<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode">
				<img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today.">
			</a>
		</div>
	<![endif]-->
	<!--[if lt IE 9]>
		<script src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css"> 
	<![endif]-->
</head>
<body id="page2">
	<!--======================== header ============================-->
	<header>
		<?php include "base/header-panel.html"; ?>
		<div class="container_12">
			<div class="grid_12 border-bottom">
				<!--======================== logo & menu ============================-->
				<?php include "base/header.php"; ?>
				<div class="clear"></div>
			</div>
			<div class="clear"></div>
		</div>
	</header>
	<!--======================== content ===========================-->
	<section id="content">
		<div class="container_12">
			<div class="wrapper">
				<div class="grid_4">
					<h3 class="p5"><span><?php echo $pagemenu['menu_name']; ?></span></h3>
					<ul id="accordion" class="accordion">
					<?php
					$servQ = mysqli_query($con, "SELECT abt_id, abt_name FROM ms_about ORDER BY abt_id ASC");
					while($serv = mysqli_fetch_array($servQ)){ $abtid = $serv['abt_id'];
					?>
					  <li>
						<div class="link"><i class="fa fa-database"></i><?php echo $serv['abt_name']; ?><i class="fa fa-chevron-down"></i></div>
						<ul class="submenu">
							<?php
							$sservQ = mysqli_query($con, "SELECT subabt_id, subabt_name FROM ms_subabout WHERE abt_id = '$abtid' ORDER BY subabt_id ASC");
							while($sserv = mysqli_fetch_array($sservQ)){
							?>
							<li><a href="about.php?id=<?php echo $sserv['subabt_id']; ?>"><?php echo $sserv['subabt_name']; ?></a></li>
							<?php } ?>
						</ul>
					  </li>
					<?php } ?>
					</ul>
				</div>
				
				<?php 
				if($id == ""){ 
				$contentQ = mysqli_query($con, "SELECT * FROM ms_subabout ORDER BY subabt_id ASC LIMIT 1");
				$content = mysqli_fetch_array($contentQ); ?>
				<div class="grid_8">
					<h3 class="p5"><?php echo $content['subabt_header']; ?></h3>
					<img src="<?php echo $content['subabt_picture']; ?>" width="100%"><br><br>
					<?php echo $content['subabt_content']; ?>
				</div>
				
				<?php 
				}else{
				$contentQ = mysqli_query($con, "SELECT * FROM ms_subabout WHERE subabt_id = '$id'");
				$content = mysqli_fetch_array($contentQ); ?>
				<div class="grid_8">
					<h3 class="p5"><?php echo $content['subabt_header']; ?></h3>
					<img src="<?php echo $content['subabt_picture']; ?>" width="100%"><br><br>
					<?php echo $content['subabt_content']; ?>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>
	
	<!--======================== footer ============================-->
	<?php include "base/footer.html"; ?>

<script>
$(function() {
	var Accordion = function(el, multiple) {
		this.el = el || {};
		this.multiple = multiple || false;

		// Variables privadas
		var links = this.el.find('.link');
		// Evento
		links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown)
	}

	Accordion.prototype.dropdown = function(e) {
		var $el = e.data.el;
			$this = $(this),
			$next = $this.next();

		$next.slideToggle();
		$this.parent().toggleClass('open');

		if (!e.data.multiple) {
			$el.find('.submenu').not($next).slideUp().parent().removeClass('open');
		};
	}	

	var accordion = new Accordion($('#accordion'), false);
});
</script>
</body>
</html>